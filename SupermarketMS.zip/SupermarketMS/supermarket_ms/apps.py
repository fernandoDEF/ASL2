from django.apps import AppConfig

class SupermarketMSConfig(AppConfig):
    name = 'supermarket_ms'
