from .category_view import CategoryList
from .category_view import CategoryDetail
from .product_view import ProductList